

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"Hospital_Management_System"

4. Download the zip file/ download winrar

5. Extract the file and copy "Hospital_Management_System" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name hospital

6. Import hospital.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Hospital_Management_System


**LOGIN DETAILS** 

Doctor
user: totonajoyce@gmail.com
pass: 12345

Admin
user: bensontesting@gmail.com
pass: programming

Patient
user: 0725667841
pass: 4066

**LOGIN DETAILS** 

Doctor
user:totonajoyce@gmail.com
pass: 12345


USER;bensonwainaina30gmail.com
PASS ; hospital


USER:heatherk@gmail.com
pass:hospital



Admin
user: bensontesting@gmail.com
pass: programming





Patient
user: 0725667841
pass: 4066




user;(ashanti)
0789654321
pass:(1972)  
0221

